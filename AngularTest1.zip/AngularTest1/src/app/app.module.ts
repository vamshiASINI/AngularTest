import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataComponent } from './data/data.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { UserComponent } from './user/user.component';
const myRoutes:Routes=[
  {
    path:'data', component : DataComponent
  },
  {
    path:'user/:id', component : UserComponent
  },
]
@NgModule({
  declarations: [
    AppComponent,
    DataComponent,
    UserComponent
  ],
  imports: [RouterModule.forRoot(myRoutes),
    BrowserModule,
    AppRoutingModule, AppRoutingModule,ReactiveFormsModule,FormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
