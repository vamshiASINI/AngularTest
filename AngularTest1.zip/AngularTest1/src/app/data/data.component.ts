import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { user } from '../model/model';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {
  totalData:any[]=[];
user:user
  id: any;
  constructor(private DataserviceService:DataserviceService) { 
    this.user=new user();
  }
  getlist(){
    this.DataserviceService.getlist().subscribe((data)=>{
      console.log(this.totalData)
      this.totalData=data
       //this.router.navigate(['/cities'])
    })
  }
  getuser(){
console.log(this.id)
  }
  ngOnInit() {
    this.getlist();
  }

  }
