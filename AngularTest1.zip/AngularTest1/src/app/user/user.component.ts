import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataserviceService } from '../dataservice.service';
import { user } from '../model/model';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  id: any;
  data: any;
user:user
  constructor(private route:ActivatedRoute, private DataserviceService:DataserviceService){ 
    this.user=new user();

  }
getList(){
  this.DataserviceService.getList(this.id).subscribe((data)=>{
    this.data=data
    console.log(data)
  })
  }
  ngOnInit() {
    this.id=this.route.snapshot.params['id']
    this.getList();
  }

}
